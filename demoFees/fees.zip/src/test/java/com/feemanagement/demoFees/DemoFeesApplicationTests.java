package com.feemanagement.demoFees;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoFeesApplicationTests {

	@Test
	void contextLoads() {
	}

}
